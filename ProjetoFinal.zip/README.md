Integrantes do trabalho: Laurent, Alexandre, Cecília e Lucas;
